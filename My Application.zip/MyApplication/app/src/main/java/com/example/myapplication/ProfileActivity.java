package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent intent = getIntent();
        String email = intent.getStringExtra("email");
        String bio = intent.getStringExtra("bio");

        TextView userEmail = findViewById(R.id.textView2);
        userEmail.setText(email);

        TextView textViewN = findViewById(R.id.textView3);

        Button add = findViewById(R.id.button3);

        if(!bio.equals("")) {
            textViewN.setText(bio);
            add.setText("Edit Bio");
            textViewN.setVisibility(View.VISIBLE);
        }

        Button back = findViewById(R.id.button4);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(ProfileActivity.this, ChoicesActivity.class);
                intent.putExtra("email", email);
                if(textViewN.getText().equals(""))
                    intent.putExtra("bio", "");
                else
                    intent.putExtra("bio", textViewN.getText());
                startActivity(intent);
                finish();
            }
        });


        add.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                EditText toAdd = findViewById(R.id.editTextTextEmailAddress2);
                if(add.getText().equals("Add Bio")){
                    toAdd.setVisibility(View.VISIBLE);
                    add.setText("Add");
                }
                else if(add.getText().equals("Add")){
                    String text = toAdd.getText().toString();
                    textViewN.setVisibility(View.VISIBLE);
                    textViewN.setText(text);
                    add.setText("Edit Bio");
                    toAdd.setVisibility(View.INVISIBLE);
                }
                else if(add.getText().equals("Edit Bio")){
                    toAdd.setVisibility(View.VISIBLE);
                    add.setText("Edit");
                }
                else if(add.getText().equals("Edit")){
                    String text = toAdd.getText().toString();
                    textViewN.setVisibility(View.VISIBLE);
                    textViewN.setText(text);
                    add.setText("Edit Bio");
                    toAdd.setVisibility(View.INVISIBLE);
                }
            }
        });
    }
}